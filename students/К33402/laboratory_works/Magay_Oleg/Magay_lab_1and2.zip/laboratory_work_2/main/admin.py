from django.contrib import admin
from .models import Conference, Comment


admin.site.register(Conference)
admin.site.register(Comment)